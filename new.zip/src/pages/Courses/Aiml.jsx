import React from 'react'

const Aiml = () => {
  return (
    <div>AIML</div>
  )
}

export default Aiml